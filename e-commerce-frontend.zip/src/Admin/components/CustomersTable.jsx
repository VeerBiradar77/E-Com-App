import React from 'react'

const CustomersTable = () => {
  return (
    <div>
      
    </div>
  )
}

export default CustomersTable
