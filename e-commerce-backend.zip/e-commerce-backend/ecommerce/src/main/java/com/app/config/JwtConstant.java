package com.app.config;

public class JwtConstant {

	public static final String SECRET_KEY="jhbgdkffsbjkhbvbbkjhdubvhbkjbskb";
	public static final String JWT_HEADER="Authorization";
}
