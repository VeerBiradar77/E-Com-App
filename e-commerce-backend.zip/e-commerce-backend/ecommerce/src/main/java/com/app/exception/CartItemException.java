package com.app.exception;

public class CartItemException extends Exception {

	public CartItemException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
