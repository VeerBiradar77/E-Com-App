package com.app.service;

import com.app.model.OrderItem;

public interface OrderItemService {

	
	public OrderItem creatOrderItem(OrderItem orderItem);
}
