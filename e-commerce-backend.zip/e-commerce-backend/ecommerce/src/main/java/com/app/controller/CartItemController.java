package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.exception.CartItemException;
import com.app.exception.UserException;
import com.app.model.CartItem;
import com.app.service.CartItemService;

@RestController
@RequestMapping("/api/cartItems") 
public class CartItemController {

    @Autowired
    private CartItemService cartItemService;

    @PostMapping("/") 
    public ResponseEntity<CartItem> createCartItem(@RequestBody CartItem cartItem) {
        CartItem createdCartItem = cartItemService.createCartItem(cartItem);
        return new ResponseEntity<>(createdCartItem, HttpStatus.CREATED);
    }

    @PutMapping("/{userId}/{id}") 
    public ResponseEntity<CartItem> updateCartItem(
            @PathVariable Long userId,
            @PathVariable Long id,
            @RequestBody CartItem cartItem) throws CartItemException, UserException {
        CartItem updatedCartItem = cartItemService.updateCartItem(userId, id, cartItem);
        return new ResponseEntity<>(updatedCartItem, HttpStatus.OK);
    }

    @GetMapping("/{cartItemId}") 
    public ResponseEntity<CartItem> getCartItemById(@PathVariable Long cartItemId) throws CartItemException {
        CartItem cartItem = cartItemService.findCartItemById(cartItemId);
        return new ResponseEntity<>(cartItem, HttpStatus.OK);
    }

    @DeleteMapping("/{userId}/{cartItemId}")
    public ResponseEntity<Void> removeCartItem(
            @PathVariable Long userId,
            @PathVariable Long cartItemId) throws CartItemException, UserException {
        cartItemService.removeCardItem(userId, cartItemId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

